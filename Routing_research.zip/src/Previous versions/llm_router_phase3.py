import os
import json
import pandas as pd
import requests
from tqdm import tqdm
import re
from concurrent.futures import ThreadPoolExecutor, as_completed

class LLMRouterV1:
    def __init__(self, model_name='llama3', taxonomy_path='../../Data/taxonomy_phase3.json'):
        self.model_name = model_name
        self.api_url = "http://localhost:11434/api/generate"
        
        # Load the taxonomy
        print(f"Loading taxonomy from {taxonomy_path}...")
        with open(taxonomy_path, 'r') as f:
            self.taxonomy = json.load(f)

    def build_system_prompt(self):
        """Constructs the prompt using all domains and labels from the taxonomy."""
        
        all_labels_text = ""
        for domain_name, domain_data in self.taxonomy['domains'].items():
            all_labels_text += f"\n### {domain_name.upper()} DOMAIN ###\n"
            for l in domain_data['labels']:
                all_labels_text += f"- {l['name']}: {l['definition']}\n"
        
        # --- FIX: Update the prompt to explicitly request the required JSON schema ---
        system_prompt = f"""You are an expert, autonomous routing agent.
Your task is to classify the user's request into EXACTLY ONE of the following routing categories across all domains:
{all_labels_text}

CRITICAL INSTRUCTION FOR AMBIGUITY (CONFIDENCE GATE):
1. If the user's request is too vague, lacks context, or does not clearly fit any of the specific categories above, you MUST route it to 'Clarification Needed'.
2. Output your response ONLY as a valid JSON object with this exact key:
{{
    "predicted_label": "The EXACT name of the category (e.g., 'Concept Explanation'). DO NOT include the domain name or any prefixes."
}}"""
        
        return system_prompt
    
    def verify_prediction(self, user_prompt, proposed_label):
        """A secondary lightweight verification step acting as a QA auditor across ALL domains."""
        
        # Build the list of ALL valid categories
        all_labels_text = ""
        for domain_name, domain_data in self.taxonomy['domains'].items():
            all_labels_text += f"\n### {domain_name.upper()} DOMAIN ###\n"
            for l in domain_data['labels']:
                all_labels_text += f"- {l['name']}: {l['definition']}\n"
        
        verification_prompt = f"""You are a strict QA auditor for a support routing system.
A previous routing agent classified a user's request, and your job is to verify if it is accurate based on the taxonomy.

VALID CATEGORIES:
{all_labels_text}

USER REQUEST: "{user_prompt}"
PROPOSED LABEL: "{proposed_label}"

Critically analyze if the PROPOSED LABEL is the absolute best fit for the USER REQUEST across all domains.
Output your response ONLY as a valid JSON object with these exact keys:
{{
    "is_correct": true or false,
    "verified_label": "If is_correct is true, output the EXACT category name without the domain. If false, output the corrected valid category name from the VALID CATEGORIES list ONLY.",
    "qa_reason": "One short sentence explaining why you confirmed or corrected the label."
}}

Do not include any markdown formatting, conversational text, or explanations outside of the JSON object.
"""
        payload = {
            "model": self.model_name,
            "prompt": verification_prompt,
            "stream": False,
            "format": "json", 
            "options": {            
                "temperature": 0.0,
                "seed": 42
            }
        }
        
        try:
            response = requests.post(self.api_url, json=payload)
            response.raise_for_status()
            return json.loads(response.json().get("response", "{}"))
        except Exception as e:
            tqdm.write(f"Verification Error -> {e}")
            return {"is_correct": True, "verified_label": proposed_label, "qa_reason": "Verification failed, defaulting to original."}

    def route_request(self, user_prompt):
        """Sends the prompt to Ollama, gets a prediction, and verifies it."""
        # --- PASS 1: Initial Generation ---
        # [Remove the 'domain' parameter from this method's signature]
        system_prompt = self.build_system_prompt()
        full_prompt = f"{system_prompt}\n\nUSER REQUEST:\n\"{user_prompt}\""
        
        payload = {
            "model": self.model_name,
            "prompt": full_prompt,
            "stream": False,
            "format": "json", 
            "options": {            
                "temperature": 0.0, 
                "seed": 42
            }
        }
        
        try:
            response = requests.post(self.api_url, json=payload)
            response.raise_for_status()
            initial_output = json.loads(response.json().get("response", "{}"))
        except Exception as e:
            tqdm.write(f"Error calling LLM for prompt: '{user_prompt[:30]}...' -> {e}")
            return {
                "initial_label": "Error",
                "predicted_label": "Error",
                "confidence_level": "Low",
                "short_reason": f"API Error: {str(e)}",
                "needs_clarification": True,
                "was_corrected": False,
                "qa_reason": "N/A"
            }

        initial_label = initial_output.get("predicted_label", "")

        # --- PASS 2 REMOVED ---
        
        # Merge the outputs
        final_label = initial_label
        
        # Build final aggregated response
        return {
            "initial_label": initial_label,
            "predicted_label": final_label,
            "confidence_level": initial_output.get("confidence_level", "Unknown"),
            "needs_clarification": initial_output.get("needs_clarification", False),
            "short_reason": initial_output.get("short_reason", ""),
            "was_corrected": False,
            "qa_reason": ""
        }

    def evaluate_benchmark(self, input_csv, output_csv):
        """Runs the LLM over the entire pilot benchmark and saves the results."""
        print(f"Loading benchmark data from {input_csv}...")
        df = pd.read_csv(input_csv)
        results = []
        
        print(f"Routing {len(df)} requests...\n")
        
        for index, row in tqdm(df.iterrows(), total=len(df), desc="Processing Requests", unit="prompt"):
            prompt_text = row['prompt']
            domain = row['domain']
            
            # Ask the LLM to route and verify it
            llm_output = self.route_request(prompt_text)
            
            result_row = {
                "prompt_id": row.get('prompt_id', f"ID-{index}"),
                "domain": domain,
                "user_prompt": prompt_text,
                "gold_label": row.get('label', ''),
                "is_ambiguous_gold": row.get('is_ambiguous', ''),
                "initial_predicted_label": llm_output.get("initial_label", ""),
                "final_predicted_label": llm_output.get("predicted_label", ""),
                "confidence_level": llm_output.get("confidence_level", ""),
                "needs_clarification_pred": llm_output.get("needs_clarification", False),
                "short_reason": llm_output.get("short_reason", ""),
                "was_corrected_by_qa": llm_output.get("was_corrected", False),
                "qa_reason": llm_output.get("qa_reason", "")
            }
            results.append(result_row)
            
        # Save to the new CSV
        results_df = pd.DataFrame(results)
        results_df.to_csv(output_csv, index=False)
        print(f"\nDone! Results saved to {output_csv}\n")
        
        # ==========================================
        # ADVANCED ACCURACY RATINGS
        # ==========================================
        
        # 1. Overall Accuracy (using final verified label)
        correct = (results_df['gold_label'] == results_df['final_predicted_label']).sum()
        total = len(results_df)
        print("="*50)
        print(f"OVERALL POST-VERIFICATION ACCURACY: {correct}/{total} ({(correct/total)*100:.2f}%)")
        print("="*50)

        # Optional: Print how many times the QA agent intervened
        corrections = results_df['was_corrected_by_qa'].sum()
        print(f"QA Interventions: {corrections} out of {total} prompts.")

        # 2. Accuracy by Domain
        if 'domain' in results_df.columns:
            print("\n--- ACCURACY BY DOMAIN ---")
            for dom in results_df['domain'].unique():
                domain_df = results_df[results_df['domain'] == dom]
                d_correct = (domain_df['gold_label'] == domain_df['final_predicted_label']).sum()
                d_total = len(domain_df)
                if d_total > 0:
                    print(f"{dom}: {d_correct}/{d_total} ({(d_correct/d_total)*100:.2f}%)")
            print("-" * 26)

        # 3. Detailed Classification Report Rating
        try:
            from sklearn.metrics import classification_report
            print("\n--- DETAILED ACCURACY RATING (Per Label) ---")
            report = classification_report(
                results_df['gold_label'], 
                results_df['final_predicted_label'], 
                zero_division=0
            )
            print(report)
        except ImportError:
            print("\n[!] Tip: Install scikit-learn (`pip install scikit-learn`) to see a detailed Accuracy Rating per category.")

# ==========================================
# Run the evaluation
# ==========================================
if __name__ == "__main__":
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    taxonomy_path = os.path.abspath(os.path.join(script_dir, "../Data/taxonomy_phase3.json"))
    benchmark_path = os.path.abspath(os.path.join(script_dir, "../Data/pilot_benchmark_phase3.csv"))
    output_path = os.path.abspath(os.path.join(script_dir, "../Data/v1_llm_results.csv"))
    
    # Initialize the router once
    router = LLMRouterV1(taxonomy_path=taxonomy_path)
    
    print("\n" + "="*50)
    print("LLM Router Interactive Mode")
    print("Type 'quit' or 'exit' to stop.")
    print("="*50 + "\n")
    
    # Loop to continuously ask the user for input
    while True:
        user_input = input("Enter your question/request: ")
        
        # Check if the user wants to exit
        if user_input.strip().lower() in ['quit', 'exit']:
            print("Exiting interactive mode...")
            break
            
        # Ignore empty inputs
        if not user_input.strip():
            continue
            
        # Route the request and print the results nicely
        print("\nRouting request...")
        single_prediction = router.route_request(user_input)
        
        print("\n--- Prediction Result ---")
        print(json.dumps(single_prediction, indent=4))
        print("-" * 25 + "\n")